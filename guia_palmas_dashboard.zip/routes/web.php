<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::get('/',function () {
    return redirect('/login');
});

Route::prefix('admin')->group(function(){    
    
    Route::get('login', 'AdminAuthController@index');
    Route::post('logar', 'AdminAuthController@logar');
    
    Route::get('dashboard', 'AdminController@index_dashboard')->middleware('admin');    
    Route::post('dashboard', 'AdminController@index_dashboard_post')->middleware('admin');    

    Route::get('minha-conta', 'AdminController@index_perfil')->middleware('admin');
    Route::post('minha-conta/editar', 'AdminController@update')->middleware('admin');
    Route::get('banners', 'AdminController@index_banners')->middleware('admin');
    Route::post('banner/cadastrar', 'AdminController@insert_foto')->middleware('admin');
    Route::post('banner/remover/{id}', 'AdminController@remover_foto')->middleware('admin');

    Route::get('avaliacoes', 'AdminController@avaliacoes')->middleware('admin');
    Route::post('avaliacao/remover/{id}', 'AdminController@delete_avaliacao')->middleware('admin');

    Route::get('categorias', 'AdminCategoriaController@index')->middleware('admin');
    Route::get('subcategorias/{id}', 'AdminCategoriaController@subcategorias')->middleware('admin');
    Route::get('categoria/cadastrar', 'AdminCategoriaController@create')->middleware('admin');
    Route::post('categoria/cadastrar', 'AdminCategoriaController@insert')->middleware('admin');
    Route::get('categoria/editar/{id}', 'AdminCategoriaController@edit')->middleware('admin');
    Route::post('categoria/editar/{id}', 'AdminCategoriaController@update')->middleware('admin');
    Route::post('categoria/remover/{id}', 'AdminCategoriaController@delete')->middleware('admin');

    Route::get('categorias-empresas', 'AdminCategoriaController@index_categorias_empresa')->middleware('admin');    
    Route::get('subcategorias-empresa/{id}', 'AdminCategoriaController@subcategorias_empresa')->middleware('admin');
    Route::get('categoria-empresa/cadastrar', 'AdminCategoriaController@create_categorias_empresa')->middleware('admin');
    Route::post('categoria-empresa/cadastrar', 'AdminCategoriaController@insert_categorias_empresa')->middleware('admin');
    Route::get('categoria-empresa/editar/{id}', 'AdminCategoriaController@edit_categorias_empresa')->middleware('admin');
    Route::post('categoria-empresa/editar/{id}', 'AdminCategoriaController@update_categorias_empresa')->middleware('admin');
    Route::post('categoria-empresa/remover/{id}', 'AdminCategoriaController@delete_categorias_empresa')->middleware('admin');

    Route::get('empresas', 'AdminEmpresaController@index')->middleware('admin');
    Route::get('empresas/pesquisa', 'AdminEmpresaController@buscar')->middleware('admin');
    Route::get('empresa/cadastrar', 'AdminEmpresaController@create')->middleware('admin');
    Route::post('empresa/cadastrar', 'AdminEmpresaController@insert')->middleware('admin');
    Route::get('empresa/editar/{id}', 'AdminEmpresaController@edit')->middleware('admin');
    Route::post('empresa/editar/{id}', 'AdminEmpresaController@update')->middleware('admin');
    Route::post('empresa/remover/{id}', 'AdminEmpresaController@delete')->middleware('admin');
    Route::post('empresa/cadastrar_fotos/{id}', 'AdminEmpresaController@insert_foto')->middleware('admin');
    Route::post('empresa/remover_foto/{id}', 'AdminEmpresaController@remover_foto')->middleware('admin');
    
    Route::get('empresa/horarios/{id}', 'AdminHorarioController@index')->middleware('admin');
    Route::post('empresa/horario/cadastrar/{id}', 'AdminHorarioController@insert')->middleware('admin');
    Route::post('empresa/horario/remover/{id}', 'AdminHorarioController@delete')->middleware('admin');

    Route::get('usuarios', 'AdminUsuarioController@index')->middleware('admin');
    Route::get('usuarios/pesquisa', 'AdminUsuarioController@buscar')->middleware('admin');
    Route::get('usuario/editar/{id}', 'AdminUsuarioController@edit')->middleware('admin');
    Route::post('usuario/editar/{id}', 'AdminUsuarioController@update')->middleware('admin');
    Route::post('usuario/remover/{id}', 'AdminUsuarioController@delete')->middleware('admin');

    Route::get('configuracoes', 'AdminConfigController@index')->middleware('admin');
    Route::post('configuracoes/cadastrar', 'AdminConfigController@insert')->middleware('admin');
    Route::post('configuracoes/editar/{id}', 'AdminConfigController@update')->middleware('admin');    

    Route::get('notificar', 'AdminController@notificar_index')->middleware('admin');
    Route::post('notificar', 'AdminController@notificar')->middleware('admin');    

});

Route::prefix('empresa')->group(function(){    
                
    Route::get('dashboard', 'EmpresaController@index_dashboard')->middleware('empresa');    
    Route::post('dashboard', 'EmpresaController@index_dashboard_post')->middleware('empresa');    

    Route::get('minha-conta', 'EmpresaController@index')->middleware('empresa');
    Route::post('minha-conta/editar', 'EmpresaController@update')->middleware('empresa');
    Route::post('galeria/cadastrar', 'EmpresaController@insert_foto')->middleware('empresa');
    Route::post('galeria/remover/{id}', 'EmpresaController@remover_foto')->middleware('empresa');    

    Route::get('horarios', 'EmpresaHorarioController@index')->middleware('empresa');
    Route::post('horario/cadastrar', 'EmpresaHorarioController@insert')->middleware('empresa');
    Route::post('horario/remover/{id}', 'EmpresaHorarioController@delete')->middleware('empresa');

    Route::get('produtos', 'EmpresaProdutoController@index')->middleware('empresa');
    Route::get('produtos/pesquisa', 'EmpresaProdutoController@buscar')->middleware('empresa');
    Route::get('produto/cadastrar', 'EmpresaProdutoController@create')->middleware('empresa');
    Route::post('produto/cadastrar', 'EmpresaProdutoController@insert')->middleware('empresa');
    Route::get('produto/editar/{id}', 'EmpresaProdutoController@edit')->middleware('empresa');
    Route::post('produto/editar/{id}', 'EmpresaProdutoController@update')->middleware('empresa');
    Route::post('produto/remover/{id}', 'EmpresaProdutoController@delete')->middleware('empresa');    
    Route::get('produto/galeria/{id}', 'EmpresaProdutoController@galeria')->middleware('empresa');
    Route::post('produto/galeria/cadastrar/{id}', 'EmpresaProdutoController@insert_foto')->middleware('empresa');
    Route::post('produto/galeria/remover/{id}', 'EmpresaProdutoController@remover_foto')->middleware('empresa');
    
    Route::get('validar-cupom', 'EmpresaCupomController@index')->middleware('empresa');
    Route::post('validar-cupom', 'EmpresaCupomController@validar')->middleware('empresa');
    
    Route::get('obter-endereco/{endereco}', 'EmpresaController@obter_endereco');
});

Route::prefix('api')->group(function(){    

    Route::post('login','ApiController@login');
    Route::post('login-facebook', 'ApiController@login_face');

    Route::post('registro','ApiController@registro');    
    Route::post('recuperar-senha','ApiController@recuperar_senha');
    Route::post('update-perfil','ApiController@update_perfil');
    Route::post('update-foto-perfil','ApiController@update_foto_perfil');

    Route::get('index','ApiController@index');
    Route::get('index/{categoria_id}/{tipo}','ApiController@index_busca');
    Route::get('index-pesquisa/{pesquisa}','ApiController@index_pesquisa');
    Route::post('index-ordenar','ApiController@index_ordenar');

    Route::get('favoritos/{id}','ApiController@favoritos');
    Route::get('cupons/{id}','ApiController@cupons');
    Route::get('loja-ofertas/{id}/{user_id}','ApiController@loja_ofertas');
    Route::get('produto/{id}/{user_id}','ApiController@produto');
    Route::get('categorias','ApiController@categorias');

    Route::post('baixar-cupom', 'ApiController@baixar_cupom');
    Route::post('excluir-cupom', 'ApiController@remover_cupom');
    Route::post('favoritar-loja', 'ApiController@favoritar_loja');
    Route::post('favoritar-produto', 'ApiController@favoritar_produto');
    Route::post('avaliar-produto', 'ApiController@avaliar_produto');
    Route::post('avaliar-empresa', 'ApiController@avaliar_empresa');    
    
    Route::get('pushToken/{id}/{token}', 'ApiController@pushToken');
    Route::get('notificar/{user_id}', 'ApiController@notificar');
});

Route::get('email', function(){
    return view('emails.registro');
});    

// Route::get('/login_success', function(){ echo "<script>window.close();</script>"; });

Route::post('logar', 'EmpresaAuthController@logar');    
Route::get('registro', 'EmpresaAuthController@index_registro');    
Route::post('registrar', 'EmpresaAuthController@registrar');    
Route::get('recuperar-senha', 'EmpresaAuthController@index_recuperar_senha');    
Route::post('recuperar-senha', 'EmpresaAuthController@recuperar_senha');    
Route::get('definir-senha/{email}/{token}', 'EmpresaAuthController@definir_senha');    
Route::post('definir-senha/{email}/{token}', 'EmpresaAuthController@definir_nova_senha');
Route::get('validar/{email}/{token}', 'EmpresaAuthController@validar');