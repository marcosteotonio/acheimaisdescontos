<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Produto extends Model
{
    protected $fillable = [
        'user_id', 'categoria_id', 'nome', 'valor', 'desconto', 'descricao', 'foto', 'promocao', 
        'validade_promocao', 'detalhes', 'ativo','tamanhos', 'sexo', 'cupom', 'video','visualizacoes'
    ];

    // protected $hidden = [
    //     'user_id'
    // ];

    public static $rules = array(                   
        'categoria_id' => 'required',
        'nome' => 'required',
        'valor' => 'required',
    );

    public static $messages = array(
        'user_id.required' => 'O campo user_id precisa ser informado. Por favor, você pode verificar isso?',
        'categoria_id.required' => 'O campo categoria precisa ser informado. Por favor, você pode verificar isso?',
        'nome.required' => 'O campo nome precisa ser informado. Por favor, você pode verificar isso?',
        'valor.required' => 'O campo valor precisa ser informado. Por favor, você pode verificar isso?',        
    );
    
    public $timestamps = false;
    protected $table = 'produtos';
}
