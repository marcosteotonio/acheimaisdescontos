<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\ServiceProvider;
use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Support\Facades\Response;

use Redirect;
use App\Cupom;

class EmpresaCupomController extends Controller
{
    public function index(){
        return view('empresa.validar_cupom');
    }

    public function validar(Request $r){

        if (isset($r->codigo)) {

            $c = Cupom::where('codigo', $r->codigo)->first();
            if (isset($c)) {

                if ($c->validado == 0) {
                    $c->validado = 1;
                    $c->save();
                    
                    Session::flash('message', 'Cupom validado com sucesso!');
                    return Redirect::back();    

                }else{
                    Session::flash('erro', 'Esse cupom já está validado!');
                    return Redirect::back();    
                }

            }else{
                Session::flash('erro', 'Código inválido!');
                return Redirect::back();    
            }

        }else{
            Session::flash('erro', 'Código inexistente!');
            return Redirect::back();
        }

    }
}
