<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\ServiceProvider;
use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Support\Facades\Response;

use DB;
use Auth;
use Mail;
use App\User;
use App\UserLoja;
use App\Produto;
use App\UserGaleria;
use App\ProdutoGaleria;
use App\Avaliacao;
use App\Categoria;
use App\CategoriaEmpresa;
use App\Cupom;
use App\Horario;
use App\Config;
use App\Favorito;

class ApiController extends Controller
{
    public function login(Request $r)
    {
        $credentials = Input::only('email', 'password');
        if ( ! Auth::attempt($credentials)) {
            return ['Dados de Login Incorretos'];
        }else{
            return Auth::user();
        }
    }

    public function login_face(Request $r)
	{
        $e = User::where('facebook_id', $r->id)->first();
        if(isset($e)){
            return $e;
        }else{				

            $u = new User();
            $u->name = $r->name;
            $u->email = $r->email;
            $u->password = bcrypt(md5(uniqid("")));
            $u->tipo = 1;
            $u->facebook_id = $r->id;

            $foto_name = md5(date('YmdHis')).'.jpg';

            $content = file_get_contents($r->picture);
            file_put_contents(base_path().'/public/uploads/usuarios/'.$foto_name, $content);
            $u->foto = $foto_name;
            $u->save();

            return $u;
        }
	}
    
    public function registro(Request $r)
    {
        $validator = Validator::make(Input::all(), User::$rules, User::$messages);
    	if ($validator->fails()) {
	        $messages = $validator->messages();
            return $messages;
        }else{			

            $u = 
            User::create([
                'name' => $r->name,
                'email' => $r->email,
                'password' => bcrypt($r->password),
                'telefone' => $r->telefone,
                'sexo' => $r->sexo,
                'nascimento' => $r->nascimento,
                'tipo' => '1',		
                'categorias' => ''
            ]);

			return $u;
        }
    }    

    public function recuperar_senha(Request $r){

        $u = User::where('email', $r->email)->first();

        if(!isset($u)){

            return [
                'erro' => 'Não foi encontrado um usuário com o email informado. Por favor, tente novamente.'
            ];
            
        }else{
            
            $u->remember_token = md5(uniqid(""));
            $u->save();
            
            $link = getenv('APP_URL').'definir-senha/'.$u->email.'/'.$u->remember_token;            
            Session::flash('email', $u->email);
            
            Mail::send('emails.recuperar_senha', ['nome' => $u->name, 'link' => $link], function ($message)
            {
                $message->from(getenv('MAIL_USERNAME'), getenv('APP_NAME'));
                $message->to(Session::get('email'));
                $message->subject('Recuperar a Senha - '.getenv('APP_NAME'));
            });

            return [
                'sucesso' => 'Verifque sua caixa de entrada para gerar sua nova senha.'
            ];            
        }

    }   

    public function index()
    {
        Produto::whereDate('validade_promocao','<',date('Y-m-d'))
                ->update(['promocao' => 0, 'validade_promocao' => null, 'cupom' => 0, 'desconto' => null]);

        $lojas = User::where('tipo',0)
                        ->where('ativo',1)
                        ->orderBy('name')
                        ->select('id','name','foto','latitude','longitude','destaque','nota')
                        ->get();

        $hoje = date('Y-m-d');
        $hora = date('h:i:s');
        $dia_semana = date('w', strtotime($hoje));
        foreach($lojas as $l){

            $horarios = Horario::where('user_id', $l->id)
                                ->where('dia', $dia_semana)
                                ->where('inicio','<=',$hora)
                                ->where('fim','>=',$hora)
                                ->count();                                                                
            
            $l->aberto = $horarios > 0;
        }
                
        $ofertas = Produto::join('users as u','u.id','=','produtos.user_id')
                            ->where('produtos.ativo',1)
                            ->orderBy('produtos.nome')
                            ->select('produtos.*','u.name as username')
                            ->get();
        
        $banners = UserGaleria::join('users as u','u.id','=','users_galerias.user_id')
                                ->where('u.tipo',null)
                                ->select('users_galerias.*')
                                ->get();        

        $arr = [ 
            'lojas' => $lojas,
            'ofertas' => $ofertas,
            'banners' => $banners
        ];

        return response()->json($arr);
    }

    public function index_busca($categoria_id, $tipo)
    {                

        if ($tipo == 0) { //lojas
            
            $lojas = User::where('tipo',0)
                        ->where('ativo',1)
                        ->where('categorias', 'LIKE', '%,'.$categoria_id.',%')
                        ->orderBy('users.name')
                        ->groupBy('users.name')
                        ->select('users.id','users.name','users.foto','users.latitude','users.longitude','users.destaque','users.nota')
                        ->get();

            $hoje = date('Y-m-d');
            $hora = date('h:i:s');
            $dia_semana = date('w', strtotime($hoje));
            foreach($lojas as $l){
                            
                $horarios = Horario::where('user_id', $l->id)
                                    ->where('dia', $dia_semana)
                                    ->where('inicio','<=',$hora)
                                    ->where('fim','>=',$hora)
                                    ->count();                                                                
                
                $l->aberto = $horarios > 0;
            }

            return ['lojas' => $lojas];

        }else if ($tipo == 1) { //ofertas

            $ofertas = Produto::join('users as u','u.id','=','produtos.user_id')
                            ->where('produtos.ativo',1)
                            ->where('categoria_id', $categoria_id)
                            ->orderBy('produtos.nome')
                            ->select('produtos.*','u.name as username')
                            ->get();

            return ['ofertas' => $ofertas];
        }        
                
        return null;
    }

    public function index_pesquisa($pesquisa){

        $lojas = User::where('name','like','%'.$pesquisa.'%')
                    ->where('ativo',1)
                    ->where('tipo',0)
                    ->orderBy('name')
                    ->select('id','name','foto','latitude','longitude','destaque','nota')
                    ->get();          
                    
        $hoje = date('Y-m-d');
        $hora = date('h:i:s');
        $dia_semana = date('w', strtotime($hoje));
        foreach($lojas as $l){
                        
            $horarios = Horario::where('user_id', $l->id)
                                ->where('dia', $dia_semana)
                                ->where('inicio','<=',$hora)
                                ->where('fim','>=',$hora)
                                ->count();                                                                
            
            $l->aberto = $horarios > 0;
        }
        
        $ofertas = Produto::join('users as u','u.id','=','produtos.user_id')
                            ->where('produtos.ativo',1)
                            ->where('produtos.nome','like','%'.$pesquisa.'%')
                            ->orderBy('produtos.nome')
                            ->select('produtos.*','u.name as username')
                            ->get();
        
        $arr = [ 
            'lojas' => $lojas,
            'ofertas' => $ofertas            
        ];

        return response()->json($arr);
    }

    public function index_ordenar(Request $r){

        $latitude = $r->latitude;
        $longitude = $r->longitude;

        if ($r->ordem == 0) { //alfabetica
            
            $lojas = User::where('tipo',0)
                        ->where('ativo',1)
                        ->orderBy('name')
                        ->select('id','name','foto','latitude','longitude','destaque','nota')
                        ->get();

            $hoje = date('Y-m-d');
            $hora = date('h:i:s');
            $dia_semana = date('w', strtotime($hoje));
            foreach($lojas as $l){
                            
                $horarios = Horario::where('user_id', $l->id)
                                    ->where('dia', $dia_semana)
                                    ->where('inicio','<=',$hora)
                                    ->where('fim','>=',$hora)
                                    ->count();                                                                
                
                $l->aberto = $horarios > 0;
            }

        }else if ($r->ordem == 1) { // mais proximo

            $lojas =
            DB::select(
                DB::raw(
                    'SELECT id, name, foto, latitude, longitude, destaque, nota,
                    (6371 * acos( cos( radians('.$latitude.') ) 
                    * cos( radians( latitude ) ) 
                    * cos( radians( longitude ) - radians('.$longitude.') ) 
                    + sin( radians('.$latitude.') ) 
                    * sin( radians( latitude ) ) ) ) AS distancia 
                    FROM users
                    WHERE tipo = 0
                    ORDER BY distancia'
                )
            );

            $hoje = date('Y-m-d');
            $hora = date('h:i:s');
            $dia_semana = date('w', strtotime($hoje));
            foreach($lojas as $l){
                            
                $horarios = Horario::where('user_id', $l->id)
                                    ->where('dia', $dia_semana)
                                    ->where('inicio','<=',$hora)
                                    ->where('fim','>=',$hora)
                                    ->count();                                                                
                
                $l->aberto = $horarios > 0;
            }

            //dd($lojas);
        }
        
        $ofertas = Produto::join('users as u','u.id','=','produtos.user_id')
                            ->where('produtos.ativo',1)
                            ->orderBy('produtos.nome')
                            ->select('produtos.*','u.name as username')
                            ->get();

        $banners = UserGaleria::join('users as u','u.id','=','users_galerias.user_id')
            ->where('u.tipo',null)
            ->select('users_galerias.*')
            ->get();

        $arr = [ 
            'lojas' => $lojas,
            'ofertas' => $ofertas,
            'banners' => $banners
        ];

        return response()->json($arr);
    }

    public function loja_ofertas($id, $user_id)
    {   
        $loja = User::find($id);        
        
        $loja->horarios = Horario::where('user_id', $id)->orderBy('dia')->orderBy('inicio')->get();

        $f = UserLoja::where('user_id',$user_id)->where('loja_id',$id)->first();

        if (isset($f)) {
            $loja->favorito = 1;
        }

        $categorias = Categoria::join('produtos as p','p.categoria_id','=','categorias.id')
                            ->where('p.user_id', $id)
                            ->orderBy('categorias.nome')
                            ->groupBy('categorias.id')
                            ->select('categorias.*')
                            ->get();

        //$ofertas = Produto::where('ativo',1)->where('user_id',$id)->orderBy('nome')->get();
        foreach($categorias as $c){
            $c->produtos = Produto::where('categoria_id', $c->id)->where('ativo',1)->where('user_id',$id)->orderBy('nome')->get();
        }

        $banners = UserGaleria::where('user_id',$id)->get();

        $arr = [ 
            'loja' => $loja,
            'ofertas' => $categorias,
            'banners' => $banners
        ];

        return response()->json($arr);
    }    

    public function produto($id, $user_id)
    {
        $config = Config::first();
        
        $produto = Produto::find($id);
        $produto->visualizacoes += 1;
        $produto->save();

        $produto_galeria = ProdutoGaleria::where('produto_id',$id)->get();
        $avaliacoes = Avaliacao::join('users as u','u.id','=','avaliacoes.user_id')
                            ->where('produto_id', $id)
                            ->orderBy('created_at','desc')
                            ->select('avaliacoes.*','u.name as nome_usuario','u.foto as foto_usuario')
                            ->limit(10)
                            ->get();

        $f = Favorito::where('user_id',$user_id)->where('produto_id',$id)->first();
        $qtd = Favorito::where('produto_id', $id)->count();

        $produto->likes = $qtd;

        if (isset($f)) {
            $produto->favorito = 1;
        }

        $arr = [
            'config' => $config,
            'produto' => $produto,
            'fotos' => $produto_galeria,
            'avaliacoes' => $avaliacoes
        ];

        return response()->json($arr);
    }

    public function favoritar_loja(Request $r){

        if (!isset($r->user_id)) return ['erro' => 'Usuário não informado.'];
        if (!isset($r->loja_id)) return ['erro' => 'Loja não informada.'];

        $loja = User::find($r->loja_id);
        if (!isset($loja)) return ['erro' => 'Loja não encontrada.'];

        $f = UserLoja::where('user_id', $r->user_id)->where('loja_id', $r->loja_id)->first();
        if (isset($f)) {
            $f->delete();
            return $loja;
        }else{
            $f = new UserLoja();
            $f->user_id = $r->user_id;
            $f->loja_id = $r->loja_id;
            $f->save();

            $loja->favorito = 1;
            return $loja;
        }
        
    }

    public function favoritar_produto(Request $r){

        if (!isset($r->user_id)) return ['erro' => 'Usuário não informado.'];
        if (!isset($r->produto_id)) return ['erro' => 'Produto não informado.'];

        $produto = Produto::find($r->produto_id);
        if (!isset($produto)) return ['erro' => 'Produto não encontrado.'];

        $f = Favorito::where('user_id', $r->user_id)->where('produto_id', $r->produto_id)->first();
        if (isset($f)) {
            $f->delete();
            return $produto;
        }else{
            $f = new Favorito();
            $f->user_id = $r->user_id;
            $f->produto_id = $r->produto_id;
            $f->save();

            $produto->favorito = 1;
            return $produto;
        }
        
    }

    public function avaliar_produto(Request $r){

        $a = new Avaliacao();
        $a->produto_id = $r->produto_id;
        $a->user_id = $r->user_id;
        $a->mensagem = $r->texto;
        $a->nota_ambiente = 0;
        $a->nota_atendimento = 0;
        $a->nota_qualidade = 0;
        $a->save();

        $avaliacoes = Avaliacao::join('users as u','u.id','=','avaliacoes.user_id')
                            ->where('produto_id', $r->produto_id)
                            ->orderBy('created_at','desc')
                            ->select('avaliacoes.*','u.name as nome_usuario','u.foto as foto_usuario')
                            ->limit(10)
                            ->get();

        return $avaliacoes;
    }

    public function avaliar_empresa(Request $r){

        $a = new Avaliacao();
        $a->empresa_id = $r->empresa_id;
        $a->user_id = $r->user_id;

        if (isset($r->mensagem))
            $a->mensagem = $r->mensagem;
        else
            $a->mensagem = '';

        $a->nota_ambiente = $r->nota_ambiente;
        $a->nota_qualidade = $r->nota_qualidade;
        $a->nota_atendimento = $r->nota_atendimento;        
        $a->save();

        //nota : (atendimento + qualidade + ambiente) / 3,

        $avaliacoes = Avaliacao::where('empresa_id', $r->empresa_id)->get();
        
        $total_atendimento = 0;
        $total_qualidade = 0;
        $total_ambiente = 0;

        $qtd = count($avaliacoes);
        foreach($avaliacoes as $av){
            $total_atendimento += $av->nota_atendimento;
            $total_qualidade += $av->nota_qualidade;
            $total_ambiente += $av->nota_ambiente;
        }

        $empresa = User::find($r->empresa_id);
        $empresa->nota_qualidade = $total_qualidade / $qtd;
        $empresa->nota_ambiente = $total_ambiente / $qtd;
        $empresa->nota_atendimento = $total_atendimento / $qtd;
        $empresa->nota = ($empresa->nota_qualidade + $empresa->nota_ambiente + $empresa->nota_atendimento) / 3;
        $empresa->save();

        return $a;
    }

    public function favoritos($id){
        $f = UserLoja::join('users as u','u.id','=','users_lojas.loja_id')
                    ->where('user_id', $id)
                    ->orderBy('u.name')
                    ->select('u.id','u.name','u.foto')
                    ->get();

        $p = Favorito::join('produtos as p','p.id','=','favoritos.produto_id')
                    ->where('favoritos.user_id', $id)
                    ->select('p.*')
                    ->get();

        
        return [
            'lojas' => $f,
            'ofertas' => $p
        ];
    }

    public function baixar_cupom(Request $r){
        
        $existe = Cupom::where('user_id', $r->user_id)
                        ->where('produto_id', $r->produto_id)
                        ->whereDate('created_at', date('Y-m-d'))
                        ->first();
        
        if (isset($existe)) { 
            return [
                'erro' => 'Você já baixou um cupom para esta oferta hoje.'
            ];
            exit;
        }

        do{
            $codigo = RAND_CODIGO();
            $existe = Cupom::where('codigo', $codigo)->first();
        }while(isset($existe));

        $c = new Cupom();
        $c->fill($r->all());
        $c->validado = 0;
        $c->codigo = $codigo;
        $c->save();

        // $cupons = Cupom::join('produtos as p','p.id','=','cupons.produto_id')
        //                 ->where('cupons.user_id',$r->user_id)
        //                 ->orderBy('cupons.created_at','desc')
        //                 ->select('cupons.*','p.nome as produto_nome','p.foto as produto_foto')
        //                 ->get();

        return [
            'cupom' => $c,
            //'cupons' => $cupons
        ];
    }

    public function cupons($id){
        $cupons = Cupom::join('produtos as p','p.id','=','cupons.produto_id')
                        ->join('users as u','u.id','=','p.user_id')
                        ->where('cupons.user_id',$id)
                        ->orderBy('cupons.created_at','desc')
                        ->select('cupons.*','p.nome as produto_nome','p.foto as produto_foto','u.name as empresa_nome','p.validade_promocao')
                        ->get();

        return $cupons;
    }

    public function remover_cupom(Request $r){
        Cupom::where('id',$r->id)->where('user_id', $r->user_id)->delete();
        
        $cupons = Cupom::join('produtos as p','p.id','=','cupons.produto_id')
                        ->join('users as u','u.id','=','p.user_id')
                        ->where('cupons.user_id',$r->user_id)
                        ->orderBy('created_at','desc')
                        ->select('cupons.*','p.nome as produto_nome','p.foto as produto_foto','u.name as empresa_nome','p.validade_promocao')
                        ->get();

        return [
            'msg' => 'sucesso',
            'cupons' => $cupons
        ];
    }

    public function categorias(){

        $categorias = Categoria::where('pai',null)->orderBy('nome')->get();
        $categorias_empresa = CategoriaEmpresa::where('pai',null)->orderBy('nome')->get();

        foreach($categorias as $c){
            $c->subcategorias = Categoria::where('pai', $c->id)->orderBy('nome')->get();
        }

        foreach($categorias_empresa as $e){
            $e->subcategorias = CategoriaEmpresa::where('pai', $e->id)->orderBy('nome')->get();
        }

        return [
            'categorias' => $categorias,
            'categorias_empresa' => $categorias_empresa
        ];
    }

    public function pushToken($id, $token)
    {
        $u = User::find($id);
        $u->token = $token;
        $u->save();
    }

    public function notificar($user_id){
        $texto = 'ola mundo';
        $r = NOTIFICAR($user_id, $texto);
        return $r;
    }

    public function update_perfil(Request $r){

        $u = User::find($r->id);

        if (!isset($u)) {
            return ['erro' => 'Usuário não encontrado.'];
            exit;
        }else{

            $u->name = $r->name;
            $u->sobrenome = $r->sobrenome;
            $u->contato = $r->contato;
            $u->sexo = $r->sexo;
            $u->nascimento = $r->nascimento;
            $u->notificacao = $r->notificacao;
            $u->save();

            return $u;
        }

    }

    public function update_foto_perfil(Request $r){

        // if($r->foto != ''){
        //     $size = $r->foto ->getClientSize();
        //     if($size > 50000){                
        //         return ['erro', 'O tamanho da imagem não pode ser maior que 50kb, por favor redimensione sua imagem e tente novamente.'];
        //         exit; 
        //     }
        // }

        $u = User::find($r->id);

        if (!isset($u)) {
            return ['erro' => 'Usuário não encontrado.'];
            exit;
        }else{

            if ($r->foto != ''){
				// $imageName = md5(date('YmdHis')).'.'.$r->file('foto')->getClientOriginalExtension();
            	// $r->file('foto')->move(base_path().'/public/uploads/usuarios/', $imageName);
                // $u->foto = $imageName;
                $file = uniqid().'.jpg';
                base64_to_jpeg($r->foto, base_path().'/public/uploads/usuarios/'.$file);
                $u->foto = $file;
                $u->save();
			}

            return $u;
        }

    }
}
