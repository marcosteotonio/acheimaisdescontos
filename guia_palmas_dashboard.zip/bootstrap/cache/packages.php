<?php return array (
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'jcf/geocode' => 
  array (
    'providers' => 
    array (
      0 => 'Jcf\\Geocode\\GeocodeServiceProvider',
    ),
    'aliases' => 
    array (
      'Geocode' => 'Jcf\\Geocode\\Facades\\Geocode',
    ),
  ),
  'fx3costa/laravelchartjs' => 
  array (
    'providers' => 
    array (
      0 => 'Fx3costa\\LaravelChartJs\\Providers\\ChartjsServiceProvider',
    ),
  ),
);