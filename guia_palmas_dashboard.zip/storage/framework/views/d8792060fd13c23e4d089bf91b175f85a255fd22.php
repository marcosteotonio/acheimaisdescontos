<?php if(isset($produto)): ?>
    <?php $__env->startSection('title', 'Editar Produto'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Cadastrar Produto'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <?php if(Session::has('errors')): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="c-alert c-alert--danger alert">
            <i class="c-alert__icon fa fa-times-circle"></i> <?php echo e($error); ?>

            <button class="c-close" data-dismiss="alert" type="button">×</button>
        </div>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>    

    <div class="row u-mb-large">
        <div class="col-md-12">
            <form class="c-search-form c-search-form--dark" method="POST" enctype="multipart/form-data" 
                <?php if(!isset($produto)): ?> 
                    action="/empresa/produto/cadastrar"
                <?php else: ?>
                    action="/empresa/produto/editar/<?php echo e($produto->id); ?>"
                <?php endif; ?>
            >
                <?php echo e(csrf_field()); ?>

                <div class="row">                    
                        
                        <div class="col-md-4 c-field u-mb-small">
                            <label class="c-field__label" for="nome">Nome</label> 
                            <input class="c-input" type="text" id="nome" name="nome" required
                            <?php if(isset($produto)): ?> value="<?php echo e($produto->nome); ?>" <?php endif; ?>> 
                        </div>

                        <div class="col-md-4 c-field u-mb-small">
                            <label class="c-field__label" for="valor">Valor (R$)</label> 
                            <input class="c-input" type="number" step=".01" id="valor" name="valor" required
                            <?php if(isset($produto)): ?> value="<?php echo e($produto->valor); ?>" <?php endif; ?>> 
                        </div> 

                        <div class="col-md-4 c-field u-mb-small">
                            <label class="c-field__label" for="desconto">Desconto (%)</label> 
                            <input class="c-input" type="number" step=".01" id="desconto" name="desconto"
                            <?php if(isset($produto)): ?> value="<?php echo e($produto->desconto); ?>" <?php endif; ?>> 
                        </div>

                        <div class="col-md-4 c-field u-mb-small">
                            <div class="c-field">
                                <label class="c-field__label" for="select1">Categoria</label>

                                <!-- Select2 jquery plugin is used -->
                                <select class="c-select has-search" id="select1" name="categoria_id">
                                    <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($c->id); ?>" <?php if(isset($produto) && $produto->categoria_id == $c->id): ?> selected <?php endif; ?>><?php echo e($c->categoria_pai); ?> - <?php echo e($c->nome); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option value="">Nenhuma Categoria Encontrada</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-2 c-field u-mb-small">
                        <div class="c-field">
                            <label class="c-field__label" for="select2">Ativo</label>

                            <!-- Select2 jquery plugin is used -->
                            <select class="c-select" id="select2" name="ativo">
                                <option value="1" <?php if(isset($produto) && $produto->ativo == 1): ?> selected <?php endif; ?>>Sim</option>
                                <option value="0" <?php if(isset($produto) && $produto->ativo == 0): ?> selected <?php endif; ?>>Não</option>                            
                            </select>
                        </div>
                        </div>

                        <div class="col-md-2 c-field u-mb-small">
                        <div class="c-field">
                            <label class="c-field__label" for="select3">Promoção</label>

                            <!-- Select2 jquery plugin is used -->
                            <select class="c-select" id="select3" name="promocao">
                                <option value="0" <?php if(isset($produto) && $produto->promocao == 0): ?> selected <?php endif; ?>>Não</option>                            
                                <option value="1" <?php if(isset($produto) && $produto->promocao == 1): ?> selected <?php endif; ?>>Sim</option>
                            </select>
                        </div>
                        </div>
                        
                        <div class="col-md-4 c-field u-mb-small">
                            <label class="c-field__label" for="desconto">Validade Promoção</label> 
                            <input class="c-input" type="date" id="validade_promocao" name="validade_promocao"
                            <?php if(isset($produto)): ?> value="<?php echo e($produto->validade_promocao); ?>" <?php endif; ?>> 
                        </div>

                        <div class="col-md-4 c-field u-mb-small">
                        <div class="c-field">
                            <label class="c-field__label" for="select6">Cupom</label>

                            <!-- Select2 jquery plugin is used -->
                            <select class="c-select" id="select6" name="cupom">
                                <option value="0" <?php if(isset($produto) && $produto->cupom == '0'): ?> selected <?php endif; ?>>Indisponível</option>
                                <option value="1" <?php if(isset($produto) && $produto->cupom == '1'): ?> selected <?php endif; ?>>Disponível</option>
                            </select>
                        </div>
                        </div>

                        <div class="col-md-2 c-field u-mb-small">
                        <div class="c-field">
                            <label class="c-field__label" for="select5">Sexo</label>

                            <!-- Select2 jquery plugin is used -->
                            <select class="c-select" id="select5" name="sexo">                                
                                <option value="0" <?php if(isset($produto) && $produto->sexo == '0'): ?> selected <?php endif; ?>>Unisex</option>
                                <option value="1" <?php if(isset($produto) && $produto->sexo == '1'): ?> selected <?php endif; ?>>Masculino</option>
                                <option value="2" <?php if(isset($produto) && $produto->sexo == '2'): ?> selected <?php endif; ?>>Feminino</option>
                            </select>
                        </div>
                        </div>

                        <div class="col-md-2">
                            <p class="u-text-mute u-mb-small">Foto Principal</p>
                            <a class="c-btn c-btn--info c-btn--fullwidth" onclick="$('#foto').click();">
                                <i class="fa fa-upload u-mr-xsmall"></i>Selecionar
                            </a>                            
                            <input id="foto" accept="image/*" name="foto" type="file" style="display:none;">                            
                        </div>

                        <div class="col-md-4 c-field u-mb-small">
                            <label class="c-field__label" for="video">Link Vídeo</label> 
                            <input class="c-input" type="text" id="video" name="video"
                            <?php if(isset($produto)): ?> value="<?php echo e($produto->video); ?>" <?php endif; ?>> 
                        </div>
                                            
                        <div class="col-md-8 u-mb-small">
                            <div class="c-field">
                                <label class="c-field__label" for="textarea2">Descrição</label>
                                <textarea class="c-input" id="textarea2" name="descricao"><?php if(isset($produto)): ?><?php echo e($produto->descricao); ?><?php endif; ?></textarea>
                            </div>
                        </div>                        

                        <div class="col-md-4 u-mb-small">
                            <div class="c-field">
                                <label class="c-field__label" for="textarea2">Tamanhos Disponíveis</label>
                                <textarea class="c-input" id="textarea2" name="tamanhos"><?php if(isset($produto)): ?><?php echo e($produto->tamanhos); ?><?php endif; ?></textarea>
                            </div>
                        </div>                        
                        
                        <div class="col-md-12 u-mb-small">
                            <div class="c-field">
                                <label class="c-field__label" for="textarea2">Mais Detalhes</label>
                                <textarea class="c-input" id="textarea2" name="detalhes"><?php if(isset($produto)): ?><?php echo e($produto->detalhes); ?><?php endif; ?></textarea>
                            </div>
                        </div>                                                                                            

                </div>               
                
                <button class="c-btn c-btn--info" type="submit">Salvar</button>                    

            </form>
        </div>                
    </div><!-- // .row -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>