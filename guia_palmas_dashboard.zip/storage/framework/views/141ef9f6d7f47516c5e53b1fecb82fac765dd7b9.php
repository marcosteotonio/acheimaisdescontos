<?php $__env->startSection('title', 'Subcategorias'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <?php if(Session::has('message')): ?>
    <div class="c-alert c-alert--success alert">
        <i class="c-alert__icon fa fa-check-circle"></i> <?php echo e(Session::get('message')); ?>

        <button class="c-close" data-dismiss="alert" type="button">×</button>
    </div>    
    <?php endif; ?>

    <?php if(Session::has('erro')): ?>
    <div class="c-alert c-alert--danger alert">
        <i class="c-alert__icon fa fa-check-circle"></i> <?php echo e(Session::get('erro')); ?>

        <button class="c-close" data-dismiss="alert" type="button">×</button>
    </div>    
    <?php endif; ?>

    <div class="row u-mb-large">
        <div class="col-12">
            <table class="c-table">
                <caption class="c-table__title">
                Subcategorias de <?php echo e($categoria->nome); ?>

                </caption>

                <thead class="c-table__head c-table__head--slim">
                    <tr class="c-table__row">                        
                        <th class="c-table__cell c-table__cell--head">Nome</th>                        
                        <th class="c-table__cell c-table__cell--head no-sort">Opções</th>
                    </tr>
                </thead>

                <tbody>
                
                <?php $__empty_1 = true; $__currentLoopData = $lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="c-table__row">                        
                        <td class="c-table__cell" style="min-width:50%"><?php echo e($c->nome); ?></td>                           
                        <td class="c-table__cell">
                            <a class="c-btn c-btn--success" href="/admin/categoria-empresa/editar/<?php echo e($c->id); ?>">
                                <i class="fa fa-pencil u-mr-xsmall"></i>Editar
                            </a>
                            <a class="c-btn c-btn--danger" onclick="REMOVER('<?php echo e($c->id); ?>', '<?php echo e($c->nome); ?>')">
                                <i class="fa fa-trash-o u-mr-xsmall"></i>Remover
                            </a>
                            <form id="delete-form-<?php echo e($c->id); ?>" action="/admin/categoria-empresa/remover/<?php echo e($c->id); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>                            
                        </td>                                    
                    </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr class="c-table__row">
                        <td class="c-table__cell" colspan="2" style="text-align:center;">
                            Nenhuma subcategoria encontrada.
                        </td>
                    </tr>   
                    <?php endif; ?>
                              

                </tbody>
            </table>
            
        </div>
    </div> 
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>

function REMOVER(id, nome){
    swal({
        title: "Remover Subcategoria!",
        html: "Você realmente deseja remover a subcategoria <br> "+nome+"?",   
        type: "warning",        
        showCancelButton: true,        
        cancelButtonText:"Cancelar",
        confirmButtonColor: "#DD6B55",   
        confirmButtonText: "Sim, desejo remover!", 
        closeOnConfirm: false 
    }).then( (result) => {        
        if (result.value) {
            document.getElementById('delete-form-'+id).submit();
        }
    });
}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>