<?php if($paginator->hasPages()): ?>
<ul class="c-pagination__list">
    
    <?php if($paginator->onFirstPage()): ?>
    <li class="c-pagination__item" class="disabled">
        <a class="c-pagination__control">
            <i class="fa fa-caret-left"></i>
        </a>
    </li>
    <?php else: ?>
    <li class="c-pagination__item">
        <a class="c-pagination__control" href="<?php echo e($paginator->previousPageUrl()); ?>">
            <i class="fa fa-caret-left"></i>
        </a>
    </li>
    <?php endif; ?>
    
    
    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php if(is_string($element)): ?>
            <li class="c-pagination__item disabled"><span><?php echo e($element); ?></span></li>
            <!-- <li class="disabled"><span><?php echo e($element); ?></span></li> -->
        <?php endif; ?>

        
        <?php if(is_array($element)): ?>
            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $paginator->currentPage()): ?>
                    <li class="c-pagination__item">
                        <a class="c-pagination__link is-active" ><?php echo e($page); ?></a>
                    </li>
                    <!-- <li class="active"><span><?php echo e($page); ?></span></li> -->
                <?php else: ?>
                    <li class="c-pagination__item"><a class="c-pagination__link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                    <!-- <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li> -->
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <?php if($paginator->hasMorePages()): ?>
        <li class="c-pagination__item">
            <a class="c-pagination__control" href="<?php echo e($paginator->nextPageUrl()); ?>">
                <i class="fa fa-caret-right"></i>
            </a>
        </li>
        <!-- <li><a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">&raquo;</a></li> -->
    <?php else: ?>
        <li class="c-pagination__item">
            <a class="c-pagination__control">
                <i class="fa fa-caret-right"></i>
            </a>
        </li>
        <!-- <li class="disabled"><span>&raquo;</span></li> -->
    <?php endif; ?>
    
</ul>
            
<?php endif; ?>