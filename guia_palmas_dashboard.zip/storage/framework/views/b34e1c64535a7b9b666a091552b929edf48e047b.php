<?php if(isset($usuario)): ?>
    <?php $__env->startSection('title', 'Editar Empresa'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Cadastrar Empresa'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

<?php if(Session::has('message')): ?>
<div class="c-alert c-alert--success alert">
    <i class="c-alert__icon fa fa-check-circle"></i> <?php echo e(Session::get('message')); ?>

    <button class="c-close" data-dismiss="alert" type="button">×</button>
</div>    
<?php endif; ?>

<?php if(Session::has('erro')): ?>
<div class="c-alert c-alert--danger alert">
    <i class="c-alert__icon fa fa-check-circle"></i> <?php echo e(Session::get('erro')); ?>

    <button class="c-close" data-dismiss="alert" type="button">×</button>
</div>    
<?php endif; ?>


<div class="row">

    <form method="post" enctype="multipart/form-data"
        <?php if(isset($usuario)): ?> action="/admin/empresa/editar/<?php echo e($usuario->id); ?>"
        <?php else: ?> action="/admin/empresa/cadastrar" <?php endif; ?>>  
    <?php echo e(csrf_field()); ?>

    <div class="col-md-12">
        <main>            

            <div class="c-card u-p-medium u-text-small u-mb-small">
                <h6 class="u-text-bold">Informações Gerais</h6>


                <div class="row">

                    <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="name">Fantasia</label> 
                        <input class="c-input" type="text" id="name" name="name" required
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->name); ?>" <?php endif; ?>> 
                    </div>

                    <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="razao_social">Razão Social</label> 
                        <input class="c-input" type="text" id="razao_social" name="razao_social"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->razao_social); ?>" <?php endif; ?>> 
                    </div>
                    
                    <div class="col-md-3 c-field u-mb-small">
                        <label class="c-field__label" for="cnpj">CNPJ</label> 
                        <input class="c-input" type="text" id="cnpj" name="cnpj" required
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->cnpj); ?>" <?php endif; ?>> 
                    </div>

                    <div class="col-md-3 c-field u-mb-small">
                        <label class="c-field__label" for="contato">Contato</label> 
                        <input class="c-input" type="text" id="contato" name="contato"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->contato); ?>" <?php endif; ?>> 
                    </div> 
                    
                    <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="email">E-mail</label> 
                        <input class="c-input" type="email" id="email" name="email" required
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->email); ?>" <?php endif; ?>>  
                    </div>

                    <div class="col-md-3 c-field u-mb-small">
                        <label class="c-field__label" for="cep">CEP</label> 
                        <input class="c-input" type="text" id="cep" name="cep" onfocusout="OBTER_ENDERECO()"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->cep); ?>" <?php endif; ?> > 
                    </div>

                    <div class="col-md-3 c-field u-mb-small">
                        <label class="c-field__label" for="estado">Estado</label> 
                        <input class="c-input" type="text" id="estado" name="estado"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->estado); ?>" <?php endif; ?> > 
                    </div>

                    <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="cidade">Cidade</label> 
                        <input class="c-input" type="text" id="cidade" name="cidade"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->cidade); ?>" <?php endif; ?> > 
                    </div>
                    
                    <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="endereco">Endereco</label> 
                        <input class="c-input" type="text" id="endereco" name="endereco"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->endereco); ?>" <?php endif; ?> > 
                    </div>

                    <div class="col-md-2 c-field u-mb-small">
                        <label class="c-field__label" for="numero">Número</label> 
                        <input class="c-input" type="text" id="numero" name="numero"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->numero); ?>" <?php endif; ?>> 
                    </div>

                    <div class="col-md-4 c-field u-mb-small">
                        <label class="c-field__label" for="bairro">Bairro</label> 
                        <input class="c-input" type="text" id="bairro" name="bairro"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->bairro); ?>" <?php endif; ?>> 
                    </div>



                    <div class="col-md-3 c-field u-mb-small">
                        <label class="c-field__label" for="latitude">Latitude</label> 
                        <input class="c-input" type="text" id="latitude" name="latitude"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->latitude); ?>" <?php endif; ?>> 
                    </div>

                    <div class="col-md-3 c-field u-mb-small">
                        <label class="c-field__label" for="longitude">Longitude</label> 
                        <input class="c-input" type="text" id="longitude" name="longitude"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->longitude); ?>" <?php endif; ?>> 
                    </div>
                    

                    <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="site">Site</label> 
                        <input class="c-input" type="text" id="site" name="site" placeholder="http://"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->site); ?>" <?php endif; ?>> 
                    </div>

                    <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="facebook">Facebook</label> 
                        <input class="c-input" type="text" id="facebook" name="facebook" placeholder="http://"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->facebook); ?>" <?php endif; ?>> 
                    </div>

                    <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="instagram">Instagram</label> 
                        <input class="c-input" type="text" id="instagram" name="instagram" placeholder="http://"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->instagram); ?>" <?php endif; ?>> 
                    </div>

                    <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="whatsapp">Whatsapp</label> 
                        <input class="c-input" type="text" id="whatsapp" name="whatsapp" placeholder="http://"
                        value="<?php echo e(isset($usuario->whatsapp) ? $usuario->whatsapp : ''); ?>"> 
                    </div>

                    <div class="col-md-4 c-field u-mb-small">
                        <label class="c-field__label" for="youtube">Youtube</label> 
                        <input class="c-input" type="text" id="youtube" name="youtube" placeholder="http://"
                        value="<?php echo e(isset($usuario->youtube) ? $usuario->youtube : ''); ?>"> 
                    </div>

                    <div class="col-md-2 c-field u-mb-small">
                        <div class="c-field">
                            <label class="c-field__label" for="select1">Ativo?</label>

                            <!-- Select2 jquery plugin is used -->
                            <select class="c-select" id="select1" name="ativo">
                                <option value="0" <?php if(isset($usuario) && $usuario->ativo == 0): ?> selected <?php endif; ?>>Não</option>                            
                                <option value="1" <?php if(isset($usuario) && $usuario->ativo == 1): ?> selected <?php endif; ?>>Sim</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <p class="u-text-mute u-mb-small">Foto Principal</p>
                        <a class="c-btn c-btn--info c-btn--fullwidth" onclick="$('#foto').click();">
                            <i class="fa fa-upload u-mr-xsmall"></i>Selecionar
                        </a>                            
                        <input id="foto" accept="image/*" name="foto" type="file" style="display:none;">                            
                    </div>

                    <div class="col-md-3 c-field u-mb-small">
                        <label class="c-field__label" for="password">Senha</label> 
                        <input class="c-input" type="password" id="password" name="password" placeholder="******"> 
                    </div>

                    <div class="col-md-3 c-field u-mb-small">
                        <label class="c-field__label" for="password_c">Repetir Senha</label> 
                        <input class="c-input" type="password" id="password_c" name="password_c" placeholder="******"> 
                    </div>

                    <div class="col-md-3 c-field u-mb-small">
                        <div class="c-field">
                            <label class="c-field__label" for="select7">Ativar cadastro?</label>

                            <!-- Select2 jquery plugin is used -->
                            <select class="c-select" id="select7" name="valido">
                                <option value="0" <?php if(isset($usuario) && $usuario->valido == 0): ?> selected <?php endif; ?>>Não</option>
                                <option value="1" <?php if(isset($usuario) && $usuario->valido == 1): ?> selected <?php endif; ?>>Sim</option>
                            </select>
                        </div>
                    </div>

                </div>  
            </div>

            <div class="c-card u-p-medium u-mb-small u-text-small">
                <h6 class="u-text-bold">Detalhes Sobre a Empresa</h6>
                <div class="row">
                <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="carro_chefe">Carro Chefe</label> 
                        <input class="c-input" type="text" id="carro_chefe" name="carro_chefe"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->carro_chefe); ?>" <?php endif; ?>> 
                    </div>                     

                    <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="tipo_ambiente">Tipo de Ambiente</label> 
                        <input class="c-input" type="text" id="tipo_ambiente" name="tipo_ambiente"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->tipo_ambiente); ?>" <?php endif; ?>> 
                    </div>
                    <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="bom_para">Bom Para</label> 
                        <input class="c-input" type="text" id="bom_para" name="bom_para"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->bom_para); ?>" <?php endif; ?>> 
                    </div>
                    <div class="col-md-3 c-field u-mb-small">
                        <div class="c-field">
                            <label class="c-field__label" for="select4">Possui Estacionamento?</label>

                            <!-- Select2 jquery plugin is used -->
                            <select class="c-select" id="select4" name="estacionamento">
                                <option value="0" <?php if(isset($usuario) && $usuario->estacionamento == 0): ?> selected <?php endif; ?>>Não</option>                            
                                <option value="1" <?php if(isset($usuario) && $usuario->estacionamento == 1): ?> selected <?php endif; ?>>Sim</option>
                            </select>
                        </div>
                        </div>
                                        
                    <div class="col-md-6 c-field u-mb-small">                        
                        <label class="c-field__label" for="detalhes">Detalhes</label> 
                        <textarea class="c-input" id="detalhes" name="detalhes"><?php if(isset($usuario)): ?><?php echo e($usuario->detalhes); ?><?php endif; ?></textarea>
                    </div>

                    <div class="col-md-6 c-field u-mb-small">                        
                        <label class="c-field__label" for="formas_pagamentos">Formas de Pagamento</label> 
                        <textarea class="c-input" id="formas_pagamentos" name="formas_pagamentos"><?php if(isset($usuario)): ?><?php echo e($usuario->formas_pagamentos); ?><?php endif; ?></textarea>
                    </div>
                    
                </div>
            </div>

            <div class="c-card u-p-medium u-mb-small">
                <h6 class="u-text-bold">Política da Empresa</h6>
                <div class="row">
                <div class="col-md-12 c-field u-mb-small">                        
                        <textarea class="c-input" id="politica" name="politica"><?php if(isset($usuario)): ?><?php echo e($usuario->politica); ?><?php endif; ?></textarea>
                    </div>
                </div>
                

            </div>

            
            <div class="c-card u-p-medium u-mb-small">
                <h6 class="u-text-bold">Configurações</h6>
                <div class="row">
                    
                    <div class="col-md-4 c-field u-mb-small">
                        <label class="c-field__label" for="lim_produtos">Limite de produtos</label> 
                        <input class="c-input" type="number" id="lim_produtos" name="lim_produtos"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->lim_produtos); ?>" <?php endif; ?>>
                    </div>

                    <div class="col-md-4 c-field u-mb-small">
                        <label class="c-field__label" for="lim_img_produtos">Limite de imagens por produto</label> 
                        <input class="c-input" type="number" id="lim_img_produtos" name="lim_img_produtos"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->lim_img_produtos); ?>" <?php endif; ?>>
                    </div>

                    <div class="col-md-4 c-field u-mb-small">
                        <label class="c-field__label" for="lim_img_usuario">Limite de imagens da loja</label> 
                        <input class="c-input" type="number" id="lim_img_usuario" name="lim_img_usuario"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->lim_img_usuario); ?>" <?php endif; ?>>
                    </div>

                    <div class="col-md-9 c-field u-mb-medium">
                        <label class="c-field__label" for="select3">Categorias da Empresa</label>
                        <?php
                            if(isset($usuario)){
                                $arr_categorias = explode(',', $usuario->categorias);
                            }
                        ?>
                        <!-- Select2 jquery plugin is used -->
                        <select class="c-select c-select--multiple" id="select3" multiple="multiple" name="categorias[]" required>
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option disabled><?php echo e($cat->nome); ?></option>
                                <?php $__currentLoopData = $cat->subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if(isset($usuario) && in_array($c->id, $arr_categorias)): ?> selected <?php endif; ?> value="<?php echo e($c->id); ?>"><?php echo e($c->nome); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-3 c-field u-mb-small">
                    <div class="c-field">
                        <label class="c-field__label" for="select5">Empresa em destaque?</label>

                        <!-- Select2 jquery plugin is used -->
                        <select class="c-select" id="select5" name="destaque">
                            <option value="0" <?php if(isset($usuario) && $usuario->destaque == 0): ?> selected <?php endif; ?>>Não</option>
                            <option value="1" <?php if(isset($usuario) && $usuario->destaque == 1): ?> selected <?php endif; ?>>Sim</option>
                        </select>
                    </div>
                    </div>
                
            </div>
            <button class="c-btn c-btn--info" type="submit">Salvar</button>
            
                       
        </main>
    </div>
    </form>

    <?php if(isset($usuario)): ?>
    <div class="col-md-12">
    <div class="c-toolbar u-mb-medium">
                <h3 class="c-toolbar__title has-divider">Galeria de fotos da Empresa</h3>
                <h5 class="c-toolbar__meta u-mr-auto"></h5>

                <a class="c-btn c-btn--info" onclick="$('#fotos').click();">
                    <i class="fa fa-upload u-mr-xsmall"></i>Selecionar
                </a>    
                <form action="/admin/empresa/cadastrar_fotos/<?php echo e($usuario->id); ?>" 
                    method="POST" enctype="multipart/form-data" style="display:none;" id="form-galeria">
                    <?php echo e(csrf_field()); ?>                
                        <input id="fotos" name="fotos[]" type="file" accept="image/*" multiple onchange="$('#form-galeria').submit()" style="display:none;">
                </form>        
            </div>
                        
            <div class="row">
                <?php $__currentLoopData = $galeria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3" style="margin-bottom: 10px;">
                    <div class="c-card u-text-center u-p-medium">
                        <div class="c-avatar c-avatar--large u-inline-flex">
                            <img src="<?php echo e(getenv('APP_URL')); ?>uploads/usuarios/<?php echo e($g->foto); ?>" style="width: 70px; height:70px;">
                        </div>

                        <div class="col-md-12" style="display: flex;justify-content: center;">
                            <a class="u-text-mute" onclick="$('#delete-form-<?php echo e($g->id); ?>').submit();"><i class="fa fa-trash"></i></a>
                        </div> 
                        <form id="delete-form-<?php echo e($g->id); ?>" action="/admin/empresa/remover_foto/<?php echo e($g->id); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>             
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    </div>
    <?php endif; ?>
   
</div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>

function OBTER_ENDERECO(){
    var cep = $('#cep').val();
    $.get("<?php echo e(getenv('APP_URL')); ?>empresa/obter-endereco/"+cep, function(data){
        console.log(data);
        $('#estado').val(data.uf);
        $('#cidade').val(data.cidade);
        $('#bairro').val(data.bairro);  
        $('#endereco').val(data.endereco);
        $('#latitude').val(data.lat);
        $('#longitude').val(data.lng);
    });

    // var lat = '';
    // var lng = '';
    // var address = endereco; //address or cep
    // geocoder.geocode( { 'address': address}, function(results, status) {
    // if (status == google.maps.GeocoderStatus.OK) {
    //     lat = results[0].geometry.location.lat();
    //     lng = results[0].geometry.location.lng();
    // } else {
    //     alert("Não foi possivel obter localização: " + status);
    // }
    // });
    // alert('Latitude: ' + lat + ' Logitude: ' + lng);
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>