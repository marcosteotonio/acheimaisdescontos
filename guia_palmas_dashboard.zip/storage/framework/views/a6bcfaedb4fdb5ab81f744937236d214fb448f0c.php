<?php $__env->startSection('title', 'Configurações'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <?php if(Session::has('message')): ?>
    <div class="c-alert c-alert--success">
        <i class="c-alert__icon fa fa-check-circle"></i> <?php echo e(Session::get('message')); ?>

    </div>
    <?php endif; ?>

    <div class="row u-mb-large">
        <div class="col-md-12">
            <form class="c-search-form c-search-form--dark" method="POST" 
                <?php if(!isset($config)): ?> 
                    action="/admin/configuracoes/cadastrar"
                <?php else: ?>
                    action="/admin/configuracoes/editar/<?php echo e($config->id); ?>"
                <?php endif; ?>
            >
                <?php echo e(csrf_field()); ?>

                <div class="row">

                    <div class="col-md-4 c-field u-mb-small">
                        <label class="c-field__label" for="lim_notificacoes_dia">Limite de notificações por dia</label> 
                        <input class="c-input" type="number" id="lim_notificacoes_dia" name="lim_notificacoes_dia"
                        <?php if(isset($config)): ?> value="<?php echo e($config->lim_notificacoes_dia); ?>" <?php endif; ?>> 
                    </div>

                    <!-- <div class="col-md-4 c-field u-mb-small">
                        <label class="c-field__label" for="lim_img_produto">Limite de imagens por produto</label> 
                        <input class="c-input" type="number" id="lim_img_produto" name="lim_img_produto"
                        <?php if(isset($config)): ?> value="<?php echo e($config->lim_img_produto); ?>" <?php endif; ?>> 
                    </div>

                    <div class="col-md-4 c-field u-mb-small">
                        <label class="c-field__label" for="lim_img_empresa">Limite de imagem por banner de empresa</label> 
                        <input class="c-input" type="number" id="lim_img_empresa" name="lim_img_empresa"
                        <?php if(isset($config)): ?> value="<?php echo e($config->lim_img_empresa); ?>" <?php endif; ?>>  
                    </div> -->

                </div>               

                <button class="c-btn c-btn--info" type="submit">Salvar</button>
            </form>
        </div>                
    </div><!-- // .row -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>