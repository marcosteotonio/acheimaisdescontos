<?php if(isset($categoria)): ?>
    <?php $__env->startSection('title', 'Editar Categoria de Empresa'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Cadastrar Categoria de Empresa'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <?php if(Session::has('errors')): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="c-alert c-alert--danger alert">
            <i class="c-alert__icon fa fa-times-circle"></i> <?php echo e($error); ?>

            <button class="c-close" data-dismiss="alert" type="button">×</button>
        </div>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>    

    <div class="row u-mb-large">
        <div class="col-md-12">
            <form class="c-search-form c-search-form--dark" method="POST" 
                <?php if(!isset($categoria)): ?> 
                    action="/admin/categoria-empresa/cadastrar"
                <?php else: ?>
                    action="/admin/categoria-empresa/editar/<?php echo e($categoria->id); ?>"
                <?php endif; ?>
            >
                <?php echo e(csrf_field()); ?>

                <div class="row">

                    <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="nome">Nome</label> 
                        <input class="c-input" type="text" id="nome" name="nome" required 
                            value="<?php echo e(isset($categoria->nome) ? $categoria->nome : ''); ?>"> 
                    </div>    

                    <div class="col-md-6 c-field u-mb-medium">
                        <label class="c-field__label" for="select2">Categoria</label>

                        <!-- Select2 jquery plugin is used -->
                        <select class="c-select has-search" id="select2" name="pai">
                            <option value="">Selecione uma categoria</option>
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(isset($categoria) && $categoria->pai == $c->id): ?> selected <?php endif; ?> value="<?php echo e($c->id); ?>"><?php echo e($c->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div> 

                    <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="icone">Ícone</label> 
                        <input class="c-input" type="text" id="icone" name="icone"
                        <?php if(isset($categoria)): ?> value="<?php echo e($categoria->icone); ?>" <?php endif; ?>> 
                    </div>    

                    <!-- <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="select2">Tipo</label>                        
                        <select class="c-select has-search" id="select2" name="tipo">
                            <option value="">Selecione um tipo</option>                            
                            <option value="0">Ofertas</option>
                            <option value="1">Cardápio</option>
                        </select>
                    </div>  -->

                    <!-- <div class="col-md-12 c-field u-mb-small">
                        <label class="c-field__label" for="select3">Categorias da Empresa</label>
                        <?php
                            if(isset($categoria)){
                                $arr_categorias = explode(',', $categoria->categorias);
                            }
                        ?>                        
                        <select class="c-select c-select--multiple" id="select3" multiple="multiple" name="categorias[]">                                                                                    
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(isset($categoria) && in_array($c->id, $arr_categorias)): ?> selected <?php endif; ?> value="<?php echo e($c->id); ?>"><?php echo e($c->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                        </select>
                    </div> -->

                </div>               
                <button class="c-btn c-btn--info" type="submit">Salvar</button>                    

            </form>
        </div>                
    </div><!-- // .row -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>