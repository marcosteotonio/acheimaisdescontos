<?php $__env->startSection('title', 'Notificar'); ?>

<?php $__env->startSection('content'); ?>


<div class="container-fluid">

<?php if(Session::has('message')): ?>
    <div class="c-alert c-alert--success alert">
        <i class="c-alert__icon fa fa-check-circle"></i> <?php echo e(Session::get('message')); ?>

        <button class="c-close" data-dismiss="alert" type="button">×</button>
    </div>    
    <?php endif; ?>

    <?php if(Session::has('erro')): ?>
    <div class="c-alert c-alert--danger alert">
        <i class="c-alert__icon fa fa-check-circle"></i> <?php echo e(Session::get('erro')); ?>

        <button class="c-close" data-dismiss="alert" type="button">×</button>
    </div>    
    <?php endif; ?>
    
    <form class="c-search-form c-search-form--dark" method="POST" enctype="multipart/form-data" 
        action="/admin/notificar">
        <?php echo e(csrf_field()); ?>

        <div class="row">    

        <div class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="select3">Tipo</label>

                        <!-- Select2 jquery plugin is used -->
                        <select class="c-select has-search" id="select3" name="tipo" onchange="CHANGE_SELECT()" required>
                            <option value="">Selecione um tipo</option>                            
                            <option value="0">Empresa</option>
                            <option value="1">Produto</option>                            
                        </select>
                    </div>

                    <div id="empresa" style="display:none;" class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="select2">Empresa</label>

                        <!-- Select2 jquery plugin is used -->
                        <select class="c-select has-search" id="select2" name="empresa_id" >
                            <option value="">Selecione uma empresa</option>
                            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($e->id); ?>"><?php echo e($e->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div> 
                    
                    <div id="produto" style="display:none;" class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="select4">Produto</label>

                        <!-- Select2 jquery plugin is used -->
                        <select class="c-select has-search" id="select4" name="produto_id" >
                            <option value="">Selecione um produto</option>
                            <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>">
                                <?php echo e($p->nome); ?> - <?php echo e($p->loja_nome); ?>                                
                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div> 

                    <div id="categoria_empresa" style="display:none;" class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="select5">Categoria de Empresa</label>

                        <!-- Select2 jquery plugin is used -->
                        <select class="c-select has-search" id="select5" name="categoria_empresa_id" >
                            <option value="">Selecione uma categoria de empresa</option>
                            <?php $__currentLoopData = $categorias_empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ce->id); ?>"><?php echo e($ce->pai_nome); ?> - <?php echo e($ce->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div> 

                    <div id="categoria_produto" style="display:none;" class="col-md-6 c-field u-mb-small">
                        <label class="c-field__label" for="select6">Categoria de Produto</label>

                        <!-- Select2 jquery plugin is used -->
                        <select class="c-select has-search" id="select6" name="categoria_id" >
                            <option value="">Selecione uma categoria de produto</option>
                            <?php $__currentLoopData = $categorias_produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cp->id); ?>"><?php echo e($cp->pai_nome); ?> - <?php echo e($cp->nome); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>                 
            
            <div class="col-md-12 c-field u-mb-small">                        
                <label class="c-field__label" for="texto">Mensagem</label> 
                <textarea class="c-input" id="texto" name="texto" required></textarea>
            </div>

        </div>
        
        <button class="c-btn c-btn--info" type="submit">Salvar</button>                    

    </form>     
    
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>

function REMOVER(id, nome){
    swal({
        title: "Remover Produto!",
        html: "Você realmente deseja remover o produto <br> "+nome+"?",   
        type: "warning",        
        showCancelButton: true,        
        cancelButtonText:"Cancelar",
        confirmButtonColor: "#DD6B55",   
        confirmButtonText: "Sim, desejo remover!", 
        closeOnConfirm: false 
    }).then( (result) => {        
        if (result.value) {
            document.getElementById('delete-form-'+id).submit();
        }
    });
}

function CHANGE_SELECT(){
    var val = $('#select3').val();
    if (val == 0) {
        $('#empresa').css('display','block');
        $('#produto').css('display','none');
        $('#categoria_empresa').css('display','none');
        $('#categoria_produto').css('display','none');        
    }else if (val == 1) {
        $('#empresa').css('display','none');
        $('#produto').css('display','block');
        $('#categoria_empresa').css('display','none');
        $('#categoria_produto').css('display','none');        
    }else if (val == 2) {
        $('#empresa').css('display','none');
        $('#produto').css('display','none');
        $('#categoria_empresa').css('display','block');
        $('#categoria_produto').css('display','none');        
    }else if (val == 3) {
        $('#empresa').css('display','none');
        $('#produto').css('display','none');
        $('#categoria_empresa').css('display','none');
        $('#categoria_produto').css('display','block');        
    }
}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>