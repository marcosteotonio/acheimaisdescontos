<?php $__env->startSection('title', 'Galeria de Fotos'); ?>

<?php $__env->startSection('content'); ?>


<div class="container-fluid">

<?php if(Session::has('message')): ?>
    <div class="c-alert c-alert--success alert">
        <i class="c-alert__icon fa fa-check-circle"></i> <?php echo e(Session::get('message')); ?>

        <button class="c-close" data-dismiss="alert" type="button">×</button>
    </div>    
    <?php endif; ?>

    <?php if(Session::has('erro')): ?>
    <div class="c-alert c-alert--danger alert">
        <i class="c-alert__icon fa fa-check-circle"></i> <?php echo e(Session::get('erro')); ?>

        <button class="c-close" data-dismiss="alert" type="button">×</button>
    </div>    
    <?php endif; ?>

    <div class="c-toolbar u-mb-medium">
        <h3 class="c-toolbar__title has-divider"><?php echo e($produto->nome); ?></h3>
        <h5 class="c-toolbar__meta u-mr-auto"></h5>

        <a class="c-btn c-btn--info" onclick="$('#fotos').click();">
            <i class="fa fa-upload u-mr-xsmall"></i>Selecionar
        </a>    
        <form action="/empresa/produto/galeria/cadastrar/<?php echo e($produto->id); ?>" 
            method="POST" enctype="multipart/form-data" style="display:none;" id="form-galeria">
            <?php echo e(csrf_field()); ?>                
                <input id="fotos" name="fotos[]" type="file" accept="image/*" multiple onchange="$('#form-galeria').submit()">                
        </form>        
    </div>

    

    <div class="row">
        <?php $__currentLoopData = $galeria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3" style="margin-bottom: 10px;">
            <div class="c-card u-text-center u-p-medium">
                <div class="c-avatar c-avatar--large u-inline-flex">
                    <img src="<?php echo e(getenv('APP_URL')); ?>uploads/produtos/<?php echo e($g->foto); ?>" style="width: 70px; height:70px;">
                </div>

                <div class="col-md-12" style="display: flex;justify-content: center;">
                    <a class="u-text-mute" onclick="$('#delete-form-<?php echo e($g->id); ?>').submit();"><i class="fa fa-trash"></i></a>
                </div> 
                <form id="delete-form-<?php echo e($g->id); ?>" action="/empresa/produto/galeria/remover/<?php echo e($g->id); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>             
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>

function REMOVER(id, nome){
    swal({
        title: "Remover Produto!",
        html: "Você realmente deseja remover o produto <br> "+nome+"?",   
        type: "warning",        
        showCancelButton: true,        
        cancelButtonText:"Cancelar",
        confirmButtonColor: "#DD6B55",   
        confirmButtonText: "Sim, desejo remover!", 
        closeOnConfirm: false 
    }).then( (result) => {        
        if (result.value) {
            document.getElementById('delete-form-'+id).submit();
        }
    });
}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>