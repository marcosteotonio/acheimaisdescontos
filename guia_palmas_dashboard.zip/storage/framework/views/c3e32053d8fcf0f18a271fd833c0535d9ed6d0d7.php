<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>


    <div class="container-fluid">
       
        <div class="row">

            <div class="col-md-6">

                <form class="c-search-form c-search-form--dark" method="POST" enctype="multipart/form-data" 
                    action="/admin/dashboard">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">     

                        <div class="col-md-6 c-field u-mb-small">
                            <label class="c-field__label" for="inicio">Data Inicial</label> 
                            <input class="c-input" type="date" id="inicio" name="inicio" value="<?php echo e(isset($inicio) ? $inicio : ''); ?>" required> 
                        </div> 
                        <div class="col-md-6 c-field u-mb-small">
                            <label class="c-field__label" for="fim">Data Final</label> 
                            <input class="c-input" type="date" id="fim" name="fim" value="<?php echo e(isset($fim) ? $fim : ''); ?>" required> 
                        </div> 

                    </div>                                   
                    <button class="c-btn c-btn--info" type="submit">Pesquisar</button>
                </form>   
            </div>            
            <div class="col-md-6">

                <form class="c-search-form c-search-form--dark" style="height: 162px;">
                    
                    <div class="row" style="display:flex; justify-content:center;">     
                        <p style="text-align:center">
                        <b>TOTAL DE CUPONS VALIDADOS</b> <br>
                        <?php echo e(date('d/m/Y',  strtotime($inicio) )); ?> - <?php echo e(date('d/m/Y',  strtotime($fim))); ?> <br>
                        <span style="font-size:35pt;"><?php echo e($total); ?></span>
                        </p>
                    </div>                                                       
                </form>   
            </div>

            <div class="col-md-6">
                <div class="c-graph-card">                                        
                    <div class="c-graph-card__chart"><div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;"><div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div></div><div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:200%;height:200%;left:0; top:0"></div></div></div>
                    <?php echo $chartjs->render(); ?>

                    </div>
                </div>
            </div>    
            <div class="col-md-6">
                <div class="c-graph-card">                                        
                    <div class="c-graph-card__chart"><div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;"><div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div></div><div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:200%;height:200%;left:0; top:0"></div></div></div>
                    <?php echo $chart->render(); ?>

                    </div>
                </div>
            </div>            

        </div><!-- // .row -->

    </div><!-- // .container -->
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>