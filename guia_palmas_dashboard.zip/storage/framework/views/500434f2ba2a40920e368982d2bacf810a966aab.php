<?php if(isset($usuario)): ?>
    <?php $__env->startSection('title', 'Editar Usuário'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Cadastrar Usuário'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <?php if(Session::has('errors')): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="c-alert c-alert--danger alert">
            <i class="c-alert__icon fa fa-times-circle"></i> <?php echo e($error); ?>

            <button class="c-close" data-dismiss="alert" type="button">×</button>
        </div>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>    

    <div class="row u-mb-large">
        <div class="col-md-12">
            <form class="c-search-form c-search-form--dark" method="POST" 
                <?php if(!isset($usuario)): ?> 
                    action="/admin/usuario/cadastrar"
                <?php else: ?>
                    action="/admin/usuario/editar/<?php echo e($usuario->id); ?>"
                <?php endif; ?>
            >
                <?php echo e(csrf_field()); ?>

                <div class="row">

                    <div class="col-md-4 c-field u-mb-small">
                        <label class="c-field__label" for="name">Nome</label> 
                        <input class="c-input" type="text" id="name" name="name" required
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->name); ?>" <?php endif; ?>> 
                    </div>     

                    <div class="col-md-4 c-field u-mb-small">
                        <label class="c-field__label" for="sobrenome">Sobrenome</label> 
                        <input class="c-input" type="text" id="sobrenome" name="sobrenome"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->sobrenome); ?>" <?php endif; ?>> 
                    </div>                
                    
                    <div class="col-md-4 c-field u-mb-small">
                        <label class="c-field__label" for="email">E-mail</label> 
                        <input class="c-input" type="email" id="email" name="email" required
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->email); ?>" <?php endif; ?>>  
                    </div>

                    <div class="col-md-4 c-field u-mb-small">
                        <label class="c-field__label" for="cpf">CPF</label> 
                        <input class="c-input" type="text" id="cpf" name="cpf" required
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->cpf); ?>" <?php endif; ?>> 
                    </div>
                    
                    <div class="col-md-4 c-field u-mb-small">
                        <label class="c-field__label" for="contato">Contato</label> 
                        <input class="c-input" type="text" id="contato" name="contato"
                        <?php if(isset($usuario)): ?> value="<?php echo e($usuario->contato); ?>" <?php endif; ?>> 
                    </div>
                    
                    <div class="col-md-4 c-field u-mb-small">
                    <div class="c-field u-mb-medium">
                        <label class="c-field__label" for="select1">Ativo</label>

                        <!-- Select2 jquery plugin is used -->
                        <select class="c-select" id="select1" name="ativo">
                            <option value="1" <?php if(isset($usuario) && $usuario->ativo == 1): ?> selected <?php endif; ?>>Sim</option>
                            <option value="0" <?php if(isset($usuario) && $usuario->ativo == 0): ?> selected <?php endif; ?>>Não</option>                            
                        </select>
                    </div>
                    </div>

                    
                    
                </div>               
                <button class="c-btn c-btn--info" type="submit">Salvar</button>                    

            </form>
        </div>                
    </div><!-- // .row -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>